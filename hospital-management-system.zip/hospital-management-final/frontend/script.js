const API = 'http://localhost:5000/api';

// Load Patients + Other Data
async function loadPatients() {
  try {
    const res = await fetch(`${API}/patients`);
    const patients = await res.json();

    // Recent Patients
    const listEl = document.getElementById('patientsList');
    listEl.innerHTML = '';
    patients.forEach((p, i) => {
      const li = document.createElement('li');
      li.textContent = `${i+1}. ${p.name} - Age: ${p.age || '-'} - Disease: ${p.disease || '-'}`;
      listEl.appendChild(li);
    });

    // Total Patients
    document.getElementById('totalPatients').textContent = patients.length;

  } catch(err) { console.error(err); }
}

// Load Appointments
async function loadAppointments() {
  try {
    const res = await fetch(`${API}/appointments`);
    const data = await res.json();
    const list = document.getElementById('appointmentsList');
    list.innerHTML = '';
    data.forEach((a, i) => {
      const li = document.createElement('li');
      li.textContent = `${i+1}. ${a.patient} with ${a.doctor} on ${a.date} at ${a.time}`;
      list.appendChild(li);
    });
  } catch(err) { console.error(err); }
}

// Load Doctors
async function loadDoctors() {
  try {
    const res = await fetch(`${API}/doctors`);
    const data = await res.json();
    const list = document.getElementById('doctorsList');
    list.innerHTML = '';
    data.forEach((d, i) => {
      const li = document.createElement('li');
      li.textContent = `${i+1}. ${d.name} - ${d.specialty || d.specialization} - ${d.phone}`;
      list.appendChild(li);
    });
  } catch(err) { console.error(err); }
}

// Load Reports
async function loadReports() {
  try {
    const res = await fetch(`${API}/reports`);
    const data = await res.json();
    const list = document.getElementById('reportsList');
    list.innerHTML = '';
    data.forEach((r, i) => {
      const li = document.createElement('li');
      li.textContent = `${i+1}. ${r.patient} - ${r.report || r.diagnosis} - ${r.date || '-'}`;
      list.appendChild(li);
    });
  } catch(err) { console.error(err); }
}

// Add Patient
async function handlePatientFormSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('p_name').value;
  const age = Number(document.getElementById('p_age').value);
  const gender = document.getElementById('p_gender').value;
  const phone = document.getElementById('p_phone').value;
  const address = document.getElementById('p_address').value;
  const disease = document.getElementById('p_disease').value;

  try {
    const res = await fetch(`${API}/patients`, {
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify({ name, age, gender, phone, address, disease })
    });
    if(!res.ok) throw new Error('Failed to add patient');
    e.target.reset();
    setTimeout(loadPatients, 200);
  } catch(err){ alert(err.message); }
}

// Sidebar navigation
function setupSidebar() {
  document.querySelectorAll('.sidebar a').forEach(link=>{
    link.addEventListener('click', e=>{
      e.preventDefault();
      const sectionId = link.getAttribute('data-section');
      document.querySelectorAll('.sidebar a').forEach(l=>l.classList.remove('active'));
      document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
      link.classList.add('active');
      document.getElementById(sectionId).classList.add('active');

      // Load page data
      if(sectionId==='patients') loadPatients();
      if(sectionId==='appointments') loadAppointments();
      if(sectionId==='doctors') loadDoctors();
      if(sectionId==='reports') loadReports();
    });
  });
}

// Initialize
document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('patientForm').addEventListener('submit', handlePatientFormSubmit);
  setupSidebar();
  loadPatients();
});
