# Hospital Management System (MongoDB + Node.js + Express)

## What's included
- Backend (Express + Mongoose) with models, routes and a seed script
- Frontend (simple HTML/CSS/JS) that connects to backend APIs
- Sample `.env`

## How to run (local)
1. Install Node.js (v16+ recommended) and MongoDB.
2. Extract this project.
3. Start MongoDB (e.g., `mongod` or use MongoDB Compass / Atlas).
4. Open terminal and run:
   ```
   cd backend
   npm install
   ```
5. Configure `backend/.env` if needed (MONGO_URI).
6. Seed sample data (optional):
   ```
   node seed.js
   ```
7. Start backend:
   ```
   npm run dev
   ```
8. Open `frontend/index.html` in your browser (or serve it with a static server).

## API Endpoints (examples)
- GET /api/patients
- POST /api/patients
- GET /api/doctors
- POST /api/appointments
- etc.

## Notes
- This is a demo starter project. For production, add authentication, validation, role-based access, input sanitization, and HTTPS.
