const express = require('express');
const router = express.Router();
const MedicalRecord = require('../models/MedicalRecord');

router.post('/', async (req, res) => {
  try {
    const r = new MedicalRecord(req.body);
    await r.save();
    res.json(r);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  const records = await MedicalRecord.find().populate('patient');
  res.json(records);
});

router.get('/:id', async (req, res) => {
  const r = await MedicalRecord.findById(req.params.id).populate('patient');
  res.json(r);
});

router.put('/:id', async (req, res) => {
  const updated = await MedicalRecord.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  await MedicalRecord.findByIdAndDelete(req.params.id);
  res.json({ message: 'Medical record deleted' });
});

module.exports = router;
