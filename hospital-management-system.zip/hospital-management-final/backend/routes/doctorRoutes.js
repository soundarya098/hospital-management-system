const express = require('express');
const router = express.Router();
const Doctor = require('../models/Doctor');

// GET all doctors
router.get('/', async (req,res)=>{
  const doctors = await Doctor.find().sort({createdAt:1});
  res.json(doctors);
});

// POST new doctor
router.post('/', async (req,res)=>{
  const doctor = new Doctor(req.body);
  await doctor.save();
  res.status(201).json(doctor);
});

module.exports = router;
