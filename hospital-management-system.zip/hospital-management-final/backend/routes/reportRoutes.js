const express = require('express');
const router = express.Router();
const Report = require('../models/Report');

// GET all reports
router.get('/', async (req,res)=>{
  const reports = await Report.find().sort({createdAt:1});
  res.json(reports);
});

// POST new report
router.post('/', async (req,res)=>{
  const report = new report(req.body);
  await report.save();
  res.status(201).json(report);
});

module.exports = router;
