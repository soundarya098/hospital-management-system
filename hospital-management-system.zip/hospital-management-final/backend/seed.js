// Run this file with `node seed.js` to insert sample data into MongoDB.
// Make sure MONGO_URI in .env points to your DB.

const mongoose = require('mongoose');
require('dotenv').config();

const Patient = require('./models/Patient');
const Doctor = require('./models/Doctor');
const Appointment = require('./models/Appointment');
const Report = require('./models/Report'); // use Report instead of MedicalRecord for frontend

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hospitalDB';

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to DB for seeding');

  // Clear all collections
  await Patient.deleteMany({});
  await Doctor.deleteMany({});
  await Appointment.deleteMany({});
  await Report.deleteMany({});

  // Seed Patients
  const patients = await Patient.insertMany([
    { name: 'Ravi Kumar', age: 30, gender: 'Male', phone: '9876543210', address: 'Chennai', disease: 'Fever' },
    { name: 'Priya Sharma', age: 25, gender: 'Female', phone: '9123456780', address: 'Bangalore', disease: 'Asthma' },
    { name: 'John Doe', age: 40, gender: 'Male', phone: '9000000000', address: 'Delhi', disease: 'Diabetes' }
  ]);

  // Seed Doctors
  const doctors = await Doctor.insertMany([
    { name: 'Dr. Mehta', specialty: 'Cardiologist', phone: '9000000000', email: 'mehta@hospital.com' },
    { name: 'Dr. Rani', specialty: 'Dermatologist', phone: '9111111111', email: 'rani@hospital.com' },
    { name: 'Dr. Smith', specialty: 'Pediatrician', phone: '9222222222', email: 'smith@hospital.com' }
  ]);

  // Seed Appointments
  await Appointment.insertMany([
    { patient: patients[0].name, doctor: doctors[0].name, date: '2025-09-20', time: '10:00 AM' },
    { patient: patients[1].name, doctor: doctors[1].name, date: '2025-09-21', time: '11:30 AM' },
    { patient: patients[2].name, doctor: doctors[2].name, date: '2025-09-22', time: '2:00 PM' }
  ]);

  // Seed Reports
  await Report.insertMany([
    { patient: patients[0].name, report: 'Blood Test', date: '2025-09-18' },
    { patient: patients[1].name, report: 'X-Ray', date: '2025-09-19' },
    { patient: patients[2].name, report: 'MRI', date: '2025-09-20' }
  ]);

  console.log('Seeding completed successfully!');
  mongoose.disconnect();
}

seed().catch(err => { console.error(err); process.exit(1); });
