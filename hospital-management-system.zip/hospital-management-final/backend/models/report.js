const mongoose = require('mongoose');

const reportSchema = new mongoose.Schema({
  patient: String,
  report: String,
  date: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('report', reportSchema);
