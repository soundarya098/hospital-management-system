const mongoose = require('mongoose');

const recordSchema = new mongoose.Schema({
  patient: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient', required: true },
  diagnosis: String,
  treatment: String,
  prescription: String,
  record_date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('MedicalRecord', recordSchema);
